package Projeto;

public interface Consumo {
    public void calcular();
}
